-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 11-11-2018 a las 18:24:51
-- Versión del servidor: 10.1.36-MariaDB
-- Versión de PHP: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `id7716333_tfg_ds_bbdd`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignaturas`
--

CREATE TABLE `asignaturas` (
  `nombre` varchar(100) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `siglas` varchar(10) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `id` int(11) NOT NULL,
  `puntos_tema` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `texto_inicial` text CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `espaciado_defecto` int(11) NOT NULL DEFAULT '10',
  `cabecera` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `asignaturas`
--

INSERT INTO `asignaturas` (`nombre`, `siglas`, `id`, `puntos_tema`, `texto_inicial`, `espaciado_defecto`, `cabecera`) VALUES
('Ingenieria del software', 'IS', 1, 'Aqui han de estar los puntos de cada tema de IS', 'Lee atentamente todas la prenguntas antes de contestar', 10, 'Esto es la cabecera de IS'),
('Fundamentos de la programacion', 'FP', 2, 'Puntos por tema de FP', 'Texto inicial de FP', 10, 'Cabecera de FP');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examenes`
--

CREATE TABLE `examenes` (
  `titulo` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `id` int(11) NOT NULL,
  `creador` int(11) NOT NULL,
  `fecha_creado` date NOT NULL,
  `fecha_modificado` date NOT NULL,
  `ultimo_modificador` int(11) NOT NULL,
  `id_asig` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `exam_preg`
--

CREATE TABLE `exam_preg` (
  `id_examen` int(11) NOT NULL,
  `id_pregunta` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `id` int(11) NOT NULL,
  `titulo` text CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `cuerpo` text COLLATE utf8_unicode_ci NOT NULL,
  `tema` int(11) NOT NULL,
  `creador` int(11) NOT NULL,
  `fecha_creacion` date NOT NULL,
  `ult_modificador` int(11) NOT NULL,
  `fecha_modificado` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesores`
--

CREATE TABLE `profesores` (
  `nombre` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `apellidos` varchar(70) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `id` int(11) NOT NULL,
  `clave` varchar(1000) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `coordinador` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `profesores`
--

INSERT INTO `profesores` (`nombre`, `apellidos`, `email`, `id`, `clave`, `coordinador`) VALUES
('Paco', 'Fernández', 'pafer@gmail.com', 3, '123', 0),
('Manolo', 'Carnero', 'macar@gmail.com', 4, '123', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prof_asig_coord`
--

CREATE TABLE `prof_asig_coord` (
  `id_profesor` int(11) NOT NULL,
  `id_asignatura` int(11) NOT NULL,
  `coordinador` tinyint(1) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `prof_asig_coord`
--

INSERT INTO `prof_asig_coord` (`id_profesor`, `id_asignatura`, `coordinador`, `id`) VALUES
(3, 1, 0, 1),
(4, 2, 0, 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asignaturas`
--
ALTER TABLE `asignaturas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key_siglas` (`siglas`),
  ADD KEY `id` (`id`);

--
-- Indices de la tabla `examenes`
--
ALTER TABLE `examenes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key_titulo` (`titulo`),
  ADD KEY `const_creador` (`creador`),
  ADD KEY `const_modificador` (`ultimo_modificador`),
  ADD KEY `const_asignatura_examen` (`id_asig`);

--
-- Indices de la tabla `exam_preg`
--
ALTER TABLE `exam_preg`
  ADD PRIMARY KEY (`id`),
  ADD KEY `const_examen` (`id_examen`),
  ADD KEY `const_pregunta` (`id_pregunta`);

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `const_creador_pregunta` (`creador`),
  ADD KEY `const_modificador_pregunta` (`ult_modificador`);

--
-- Indices de la tabla `profesores`
--
ALTER TABLE `profesores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key_email` (`email`);

--
-- Indices de la tabla `prof_asig_coord`
--
ALTER TABLE `prof_asig_coord`
  ADD PRIMARY KEY (`id`),
  ADD KEY `const_asignatura` (`id_asignatura`),
  ADD KEY `const_profesor` (`id_profesor`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asignaturas`
--
ALTER TABLE `asignaturas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `examenes`
--
ALTER TABLE `examenes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `profesores`
--
ALTER TABLE `profesores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `prof_asig_coord`
--
ALTER TABLE `prof_asig_coord`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `examenes`
--
ALTER TABLE `examenes`
  ADD CONSTRAINT `const_asignatura` FOREIGN KEY (`id_asig`) REFERENCES `asignaturas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `const_creador` FOREIGN KEY (`creador`) REFERENCES `profesores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `const_modificador` FOREIGN KEY (`ultimo_modificador`) REFERENCES `profesores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `exam_preg`
--
ALTER TABLE `exam_preg`
  ADD CONSTRAINT `const_examen` FOREIGN KEY (`id_examen`) REFERENCES `examenes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `const_pregunta` FOREIGN KEY (`id_pregunta`) REFERENCES `preguntas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD CONSTRAINT `const_creador_pregunta` FOREIGN KEY (`creador`) REFERENCES `profesores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `const_modificador_pregunta` FOREIGN KEY (`ult_modificador`) REFERENCES `profesores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `prof_asig_coord`
--
ALTER TABLE `prof_asig_coord`
  ADD CONSTRAINT `const_asignaturas` FOREIGN KEY (`id_asignatura`) REFERENCES `asignaturas` (`id`),
  ADD CONSTRAINT `const_profesor` FOREIGN KEY (`id_profesor`) REFERENCES `profesores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
